package main

import "contact/startup"

func main() {
	startup.Server()
}
