package message

import (
	"github.com/gin-gonic/gin"
	"contact/api/message/dto"
	coredto "github.com/afteracademy/goserve/v2/dto"
	"github.com/afteracademy/goserve/v2/network"
	"github.com/afteracademy/goserve/v2/utility"
)

type controller struct {
	network.BaseController
	service Service
}

func NewController(
	authMFunc network.AuthenticationProvider,
	authorizeMFunc network.AuthorizationProvider,
	service Service,
) network.Controller {
	return &controller{
		BaseController: network.NewBaseController("/message", authMFunc, authorizeMFunc),
		service:  service,
	}
}

func (c *controller) MountRoutes(group *gin.RouterGroup) {
	group.GET("/id/:id", c.getMessageHandler)
}

func (c *controller) getMessageHandler(ctx *gin.Context) {
	uuidParam, err := network.ReqParams(ctx, coredto.EmptyUUID())
	if err != nil {
		// TODO
		// Do check https://github.com/afteracademy/goserve-example-api-server-postgres/blob/main/api/contact/controller.go
		// to know how to handle response properly 
		return
	}

	message, err := c.service.FindMessage(uuidParam.ID)
	if err != nil {
		// TODO
		// Do check https://github.com/afteracademy/goserve-example-api-server-postgres/blob/main/api/contact/controller.go
		// to know how to handle response properly 
		return
	}

	data, err := utility.MapTo[dto.InfoMessage](message)
	if data == nil || err != nil {
		// TODO
		// Do check https://github.com/afteracademy/goserve-example-api-server-postgres/blob/main/api/contact/controller.go
		// to know how to handle response properly 
		return
	}

	// TODO
	// Do check https://github.com/afteracademy/goserve-example-api-server-postgres/blob/main/common/payload.go
	// to know how to handle response properly 
}
