package message

import (
	"github.com/gin-gonic/gin"
	"sample/api/message/dto"
	coredto "github.com/afteracademy/goserve/v2/dto"
	"github.com/afteracademy/goserve/v2/network"
	"github.com/afteracademy/goserve/v2/utility"
)

type controller struct {
	network.Controller
	service Service
}

func NewController(
	authMFunc network.AuthenticationProvider,
	authorizeMFunc network.AuthorizationProvider,
	service Service,
) network.Controller {
	return &controller{
		Controller: network.NewController("/message", authMFunc, authorizeMFunc),
		service:  service,
	}
}

func (c *controller) MountRoutes(group *gin.RouterGroup) {
	group.GET("/id/:id", c.getMessageHandler)
}

func (c *controller) getMessageHandler(ctx *gin.Context) {
	uuidParam, err := network.ReqParams[coredto.UUID](ctx)
	if err != nil {
		network.SendBadRequestError(ctx, err.Error(), err)
		return
	}

	message, err := c.service.FindMessage(uuidParam.ID)
	if err != nil {
		network.SendBadRequestError(ctx, err.Error(), err)
		return
	}

	data, err := utility.MapTo[dto.InfoMessage](message)
	if data == nil || err != nil {
		network.SendBadRequestError(ctx, err.Error(), err)
		return
	}

	network.SendSuccessDataResponse(ctx, "success", data)
}
