package dto

import (
	"time"

	"github.com/google/uuid"
)

type InfoMessage struct {
	ID        uuid.UUID `json:"_id" binding:"required"`
	Field     string    `json:"field" binding:"required"`
	CreatedAt time.Time `json:"createdAt" binding:"required"`
}
