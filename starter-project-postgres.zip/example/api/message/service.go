package message

import (
	"context"
  "contact/api/message/dto"
	"contact/api/message/model"

	"github.com/afteracademy/goserve/v2/network"
	"github.com/afteracademy/goserve/v2/redis"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5/pgxpool"
)

type Service interface {
	FindMessage(id uuid.UUID) (*model.Message, error)
}

type service struct {
	network.BaseService
	db          *pgxpool.Pool
	infoMessageCache redis.Cache[dto.InfoMessage]
}

func NewService(db *pgxpool.Pool, store redis.Store) Service {
	return &service{
		BaseService: network.NewBaseService(),
		db:          db,
		infoMessageCache: redis.NewCache[dto.InfoMessage](store),
	}
}

func (s *service) FindMessage(id uuid.UUID) (*model.Message, error) {
	ctx := context.Background()

	query := `
		SELECT
			id,
			field,
			status,
			created_at,
			updated_at
		FROM messages
		WHERE id = $1
	`

	var m model.Message

	err := s.db.QueryRow(ctx, query, id).
		Scan(
			&m.ID,
			&m.Field,
			&m.Status,
			&m.CreatedAt,
			&m.UpdatedAt,
		)

	if err != nil {
		return nil, err
	}

	return &m, nil
}
