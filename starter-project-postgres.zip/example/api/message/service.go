package message

import (
	"context"
  "sample/api/message/dto"
	"sample/api/message/model"

	"github.com/afteracademy/goserve/v2/redis"
	"github.com/afteracademy/goserve/v2/postgres"
	"github.com/google/uuid"
)

type Service interface {
	FindMessage(id uuid.UUID) (*model.Message, error)
}

type service struct {
	db          postgres.Database
	infoMessageCache redis.Cache[dto.InfoMessage]
}

func NewService(db postgres.Database, store redis.Store) Service {
	return &service{
		db:          db,
		infoMessageCache: redis.NewCache[dto.InfoMessage](store),
	}
}

func (s *service) FindMessage(id uuid.UUID) (*model.Message, error) {
	ctx := context.Background()

	query := `
		SELECT
			id,
			field,
			status,
			created_at,
			updated_at
		FROM messages
		WHERE id = $1
	`

	var m model.Message

	err := s.db.Pool().QueryRow(ctx, query, id).
		Scan(
			&m.ID,
			&m.Field,
			&m.Status,
			&m.CreatedAt,
			&m.UpdatedAt,
		)

	if err != nil {
		return nil, err
	}

	return &m, nil
}
