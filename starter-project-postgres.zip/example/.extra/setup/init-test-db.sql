-- Create test user
CREATE USER test_db_user WITH PASSWORD 'changeit';

-- Create test database
CREATE DATABASE test_db OWNER test_db_user;

GRANT ALL PRIVILEGES ON DATABASE test_db TO test_db_user;
