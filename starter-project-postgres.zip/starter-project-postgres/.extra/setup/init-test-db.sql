-- Create test user
CREATE USER example_test_db_user WITH PASSWORD 'changeit';

-- Create test database
CREATE DATABASE example_test_db OWNER example_test_db_user;

GRANT ALL PRIVILEGES ON DATABASE example_test_db TO example_test_db_user;
