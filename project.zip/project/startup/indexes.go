package startup

import (
	"github.com/afteracademy/goserve/arch/mongo"
	sampleModel "github.com/yourusername/example/api/sample/model"
)

func EnsureDbIndexes(db mongo.Database) {
	go mongo.Document[sampleModel.Sample](&sampleModel.Sample{}).EnsureIndexes(db)
}
