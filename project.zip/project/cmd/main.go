package main

import "github.com/yourusername/example/startup"

func main() {
	startup.Server()
}
