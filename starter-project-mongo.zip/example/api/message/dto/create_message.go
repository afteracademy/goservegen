package dto

import (
	"time"

	"github.com/go-playground/validator/v10"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"github.com/afteracademy/goserve/v2/utility"
)

type InfoMessage struct {
	ID        primitive.ObjectID `json:"_id" binding:"required"`
	Field     string             `json:"field" binding:"required"`
	CreatedAt time.Time          `json:"createdAt" binding:"required"`
}

func EmptyInfoMessage() *InfoMessage {
	return &InfoMessage{}
}

func (d *InfoMessage) GetValue() *InfoMessage {
	return d
}

func (d *InfoMessage) ValidateErrors(errs validator.ValidationErrors) ([]string, error) {
	return utility.FormatValidationErrors(errs), nil
}
