package message

import (
  "sample/api/message/dto"
	"sample/api/message/model"
	"github.com/afteracademy/goserve/v2/mongo"
	"github.com/afteracademy/goserve/v2/redis"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
)

type Service interface {
	FindMessage(id primitive.ObjectID) (*model.Message, error)
}

type service struct {
	messageQueryBuilder mongo.QueryBuilder[model.Message]
	infoMessageCache    redis.Cache[dto.InfoMessage]
}

func NewService(db mongo.Database, store redis.Store) Service {
	return &service{
		messageQueryBuilder: mongo.NewQueryBuilder[model.Message](db, model.CollectionName),
		infoMessageCache: redis.NewCache[dto.InfoMessage](store),
	}
}

func (s *service) FindMessage(id primitive.ObjectID) (*model.Message, error) {
	filter := bson.M{"_id": id}

	msg, err := s.messageQueryBuilder.SingleQuery().FindOne(filter, nil)
	if err != nil {
		return nil, err
	}

	return msg, nil
}
