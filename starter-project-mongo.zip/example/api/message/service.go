package message

import (
  "contact/api/message/dto"
	"contact/api/message/model"
	"github.com/afteracademy/goserve/v2/mongo"
	"github.com/afteracademy/goserve/v2/network"
	"github.com/afteracademy/goserve/v2/redis"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
)

type Service interface {
	FindMessage(id primitive.ObjectID) (*model.Message, error)
}

type service struct {
	network.BaseService
	messageQueryBuilder mongo.QueryBuilder[model.Message]
	infoMessageCache    redis.Cache[dto.InfoMessage]
}

func NewService(db mongo.Database, store redis.Store) Service {
	return &service{
		BaseService:  network.NewBaseService(),
		messageQueryBuilder: mongo.NewQueryBuilder[model.Message](db, model.CollectionName),
		infoMessageCache: redis.NewCache[dto.InfoMessage](store),
	}
}

func (s *service) FindMessage(id primitive.ObjectID) (*model.Message, error) {
	filter := bson.M{"_id": id}

	msg, err := s.messageQueryBuilder.SingleQuery().FindOne(filter, nil)
	if err != nil {
		return nil, err
	}

	return msg, nil
}
