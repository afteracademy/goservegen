package message

import (
	"github.com/gin-gonic/gin"
	"sample/api/message/dto"
	coredto "github.com/afteracademy/goserve/v2/dto"
	"github.com/afteracademy/goserve/v2/network"
	"github.com/afteracademy/goserve/v2/utility"
)

type controller struct {
	network.Controller
	service Service
}

func NewController(
	authMFunc network.AuthenticationProvider,
	authorizeMFunc network.AuthorizationProvider,
	service Service,
) network.Controller {
	return &controller{
		Controller: network.NewController("/message", authMFunc, authorizeMFunc),
		service:  service,
	}
}

func (c *controller) MountRoutes(group *gin.RouterGroup) {
	group.GET("/id/:id", c.getMessageHandler)
}

func (c *controller) getMessageHandler(ctx *gin.Context) {
	mongoId, err := network.ReqParams[coredto.MongoId](ctx)
	if err != nil {
		network.SendBadRequestError(ctx, err.Error(), err)
		return
	}

	message, err := c.service.FindMessage(mongoId.ID)
	if err != nil {
		network.SendBadRequestError(ctx, err.Error(), err)
		return
	}

	data, err := utility.MapTo[dto.InfoMessage](message)
	if data == nil || err != nil {
		network.SendBadRequestError(ctx, err.Error(), err)
		return
	}

	network.SendSuccessDataResponse(ctx, "success", data)
}
