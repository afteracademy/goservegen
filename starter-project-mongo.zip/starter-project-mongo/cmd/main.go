package main

import "sample/startup"

func main() {
	startup.Server()
}
