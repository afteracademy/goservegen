function seed(dbName, user, password) {
  db = db.getSiblingDB(dbName);
  db.createUser({
    user: user,
    pwd: password,
    roles: [{ role: "readWrite", db: dbName }],
  });
}

seed("example-dev-db", "example-dev-db-user", "changeit");
seed("example-test-db", "example-test-db-user", "changeit");
