package startup

import (
	"github.com/afteracademy/goserve/v2/mongo"
	messageModel "sample/api/message/model"
)

func EnsureDbIndexes(db mongo.Database) {
	go mongo.Document[messageModel.Message](&messageModel.Message{}).EnsureIndexes(db)
}
